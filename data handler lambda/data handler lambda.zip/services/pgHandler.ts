
import ServerlessClient from 'serverless-postgres';
import { IDBQueryResult, IDeviceInfo } from '../types';

process.env.RDS_HOSTNAME = "ec2-63-32-7-190.eu-west-1.compute.amazonaws.com";
process.env.RDS_DB_NAME = "d10m99eh7q0a6d";
process.env.RDS_USERNAME = "nhwikhzdnttvfo";
process.env.RDS_PASSWORD = "651242160e2bbbb3faf0986803b8c64b6d76cb53e5aebb6fdb58bd757363c7b9";

class PGHandler {

  private client : ServerlessClient;

  constructor(){
    
    if(process.env.RDS_HOSTNAME == null || process.env.RDS_DB_NAME == null
      || process.env.RDS_USERNAME == null || process.env.RDS_PASSWORD == null){
        throw new Error("Missing required environment variables for connecting to PostreSQL DB.");
    }

    this.client = new ServerlessClient({
      user: process.env.RDS_USERNAME,
      host: process.env.RDS_HOSTNAME,
      database: process.env.RDS_DB_NAME,
      password: process.env.RDS_PASSWORD,
      ssl: { rejectUnauthorized: false },
      port: 5432,
      maxConnections: 2
    });
  }

  public async connect(){
    await this.client.connect();
  }

  public async clean(){
    await this.client.clean();
  }

  public async getAllDevicesWithDeviceNameIn(ids : number[]) : Promise<IDBQueryResult<IDeviceInfo>> {
    const text = 'SELECT organization, room, id FROM device WHERE id = ANY ($1)'
    return await this.client.query(text,  [ids]);
  }

}

const pgHandler = new PGHandler();
export default pgHandler;
