process.env.INFLUX_HOSTNAME = "https://eu-central-1-1.aws.cloud2.influxdata.com";
process.env.INFLUX_TOKEN = "rzx-z0wHCexzzR8o71XhoJA_WAUL-leJ2u093J3rImmKgi7wOg3tFoO9l2Y8FqsWqldBEkQXwTMUNEMAv7WDuQ==";
process.env.INFLUX_ORG = "305b9d986db712e4";

process.env.RDS_HOSTNAME = "ec2-63-34-130-73.eu-west-1.compute.amazonaws.com";
process.env.RDS_DB_NAME = "d9m3b06ke80rhd";
process.env.RDS_USERNAME = "ioadjrjwozeejc";
process.env.RDS_PASSWORD = "ed672e2c39aa54e18353663be185bb0259cd6a9eae8782b4868336a5bfe1ad86";

export const set = true;